//
//  BleNightpatrolPeripheral.m
//  BLEMemberManager
//
//  Created by xiaweidong on 16/3/11.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import "BlePatrolPeripheral.h"

@implementation BlePatrolPeripheral

- (instancetype)init
{
    if (self= [super init]) {
        self.m_peripheralType     = @"";
        self.m_peripheralLocaName = @"";
        self.m_peripheralRSSI     = 0;
    }
    return self;
}

@end
