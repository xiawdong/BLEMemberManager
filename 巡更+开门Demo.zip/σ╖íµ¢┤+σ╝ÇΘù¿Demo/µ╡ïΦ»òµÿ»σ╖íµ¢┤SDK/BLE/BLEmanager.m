//
//  BLEmanager.m
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved
//

#import <UIKit/UIKit.h>
#import "BLEmanager.h"
#import "BlePatrolPeripheral.h"
#import "StringConvert.h"
#import "Commom.h"
#import "Ble_lock.h"


static NSString * const BLE_DOORLOCK_ID = @"211"; //!<门锁大门
static NSString * const BLE_LOCK_ID     = @"2111";//!<门锁ID
static NSString * const BLE_PATROL_ID   = @"1311";//!<巡更ID
static double const SCAN_TIMER          = 0.2;    //!<扫描频率

@interface BLEmanager ()

{
    CBCentralManager *_m_manger;
    CBPeripheral     *_m_peripheral;
    NSTimer          *_connectTimer;     //!< 3s循环扫描
    Ble_lock         *ble_lock;
}

@end

@implementation BLEmanager
@synthesize m_manger;
@synthesize m_peripheral;
@synthesize m_array_peripheral;
@synthesize mange_delegate;


//单例
#undef	AS_SINGLETON
#define AS_SINGLETON( __class ) \
+ (__class *)sharedInstance;

#undef	DEF_SINGLETON
#define DEF_SINGLETON( __class ) \
+ (__class *)sharedInstance \
{ \
static dispatch_once_t once; \
static __class * __singleton__; \
dispatch_once( &once, ^{ __singleton__ = [[__class alloc] init]; } ); \
return __singleton__; \
}

static BLEmanager *sharedBLEmanger=nil;

- (instancetype)init
{
    self = [super init];
    if (self) {
        if (!m_array_peripheral) {
            
            m_manger = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
            m_array_peripheral = [[NSMutableArray alloc]init];
            ble_lock = [[Ble_lock alloc] init];
        }
    }
    return self;
}

+(BLEmanager *)shareInstance;
{
    @synchronized(self){
        if (sharedBLEmanger == nil) {
            sharedBLEmanger = [[self alloc]init];
        }
    }
    return sharedBLEmanger;
}

-(void)initCentralManger;
{
    m_manger = [[CBCentralManager alloc]initWithDelegate:self queue:nil];
}


- (void)scanfunction
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //开始扫描设备
        
        [m_manger scanForPeripheralsWithServices:nil options:nil];
        
    });
    
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central;
{
    
    switch (central.state) {
        case CBCentralManagerStatePoweredOff:{
            [_connectTimer setFireDate:[NSDate distantFuture]];
            self.m_centralState = NO;
        }
            break;
        case CBCentralManagerStateUnsupported:{
            
        }
            break;
        case CBCentralManagerStatePoweredOn:
            // 开启定时器
            [_connectTimer setFireDate:[NSDate distantPast]];
            // 计时器
            _connectTimer =  [NSTimer scheduledTimerWithTimeInterval:SCAN_TIMER target:self selector:@selector(scanfunction) userInfo:nil repeats:YES];
            [[NSRunLoop mainRunLoop]addTimer:_connectTimer forMode:NSRunLoopCommonModes];
            self.m_centralState = YES;
            break;
        default:
            break;
    }
    
}


- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    //根据广播包带出来的设备名，初步判断:门锁(211);巡更(1311)
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //数据处理
        
        NSString * peripheralID = [StringConvert ConvertStringToHexString:advertisementData[@"kCBAdvDataLocalName"]];
        
        if ([peripheralID hasPrefix:BLE_DOORLOCK_ID] && [peripheralID length]==12){
            
            [ble_lock add_lock:peripheral :peripheralID :@"00001" :0 :0 :0 :0 :-90];
            
            [ble_lock set_rssi:peripheralID :[RSSI doubleValue]];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [mange_delegate bleMangerDidDiscoverPeripheral:ble_lock advertisementData:advertisementData PeripheralType:[BLE_LOCK_ID integerValue]];
            });
            
        }else if ([peripheralID hasPrefix:BLE_PATROL_ID] && [peripheralID length]==12){
            BOOL isExist = [self comparePeripheralisEqual:peripheral RSSI:RSSI peripheralID:peripheralID];
            
            if (!isExist) {
                
                BlePatrolPeripheral * l_per  = [[BlePatrolPeripheral alloc]init];
                l_per.m_peripheral           = peripheral;
                l_per.m_peripheralType       = @"巡更设备";
                l_per.m_peripheralLocaName   = peripheralID;
                l_per.m_peripheralRSSI       = RSSI;
                
                [m_array_peripheral addObject:l_per];
                
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                [mange_delegate bleMangerDidDiscoverPeripheral:peripheral advertisementData:advertisementData PeripheralType:[BLE_PATROL_ID integerValue]];
            });
            
        }
        
    });
    
    
}
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    
    [m_manger stopScan];
    
    m_peripheral = peripheral;
    m_peripheral.delegate = self;
    [m_peripheral discoverServices:nil];
    [mange_delegate bleMangerConnectedPeripheral:YES];
    
        NSLog(@"已经连接上了: %@",peripheral.name);
    
}


- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    //苹果的官方解释 {@link connectPeripheral:options:} ,也就是说链接外设失败了
    NSLog(@"链接外设失败");
}


- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    
    NSLog(@"didDisconnectPeripheral");
    
    //如果你想要尝试回连外设，可以在这里调用一下链接函数
    /*
     [central connectPeripheral:peripheral options:@{CBCentralManagerScanOptionSolicitedServiceUUIDsKey : @YES,CBConnectPeripheralOptionNotifyOnDisconnectionKey:@YES}];
     */
    [mange_delegate bleMangerDisConnectedPeripheral:peripheral];
    
}




- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(NSError *)error NS_AVAILABLE(NA, 8_0)
{
    
    //[peripheral readRSSI];方法回调的RSSI，你可以根据这个RSSI估算一下距离什么的
    NSLog(@" peripheral Current RSSI:%@",RSSI);
    
}


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error
{
    
    for (CBService *s in [peripheral services]) {
        [peripheral discoverCharacteristics:nil forService:s];
    }
    
}


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    //发现了（指定）的特征值了，如果你想要有所动作，你可以直接在这里做，比如有些属性为 notify 的 Characteristics ,你想要监听他们的值，可以这样写
    if (error) {
        return;
    }
    for (CBCharacteristic *c in service.characteristics) {
        if ([[c.UUID UUIDString] isEqualToString:@"FFF1"]) {
            [peripheral setNotifyValue:YES forCharacteristic:c]; //不想监听的时候，设置为：NO 就行了
            [peripheral readValueForCharacteristic:c];
            self.m_writeCharacteristic = c;
        }else if ([[c.UUID UUIDString] isEqualToString:@"FFF4"]){
            [peripheral setNotifyValue:YES forCharacteristic:c];
        }
    }
    
    
}


- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        return;
    }
    
//        Byte *resultByte = (Byte *)[characteristic.value bytes];
//        for (int i = 0 ; i < [characteristic.value length]; i ++) {
//            printf("resultByte = %x\n",resultByte[i]);
//    
//        }
//        NSLog(@"receiveData = %@",characteristic.value);
    
    [mange_delegate bleMangerReceiveDataPeripheralData:characteristic.value from_Characteristic:characteristic];
    
}


- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    
    if (!error) {
        NSLog(@"发送成功");
    }else{
        NSLog(@"发送失败！characteristic.uuid为：%@",[characteristic.UUID UUIDString]);
    }
    
}


- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error

{
    //这个方法被调用是因为你主动调用方法： setNotifyValue:forCharacteristic 给你的反馈
    //    NSLog(@"你更新了对特征值:%@ 的通知",[characteristic.UUID UUIDString]);
    
}

-(BOOL)comparePeripheralisEqual:(CBPeripheral *)disCoverPeripheral RSSI:(NSNumber *)RSSI peripheralID:(NSString *)peripheralID
{
    if ([m_array_peripheral count]>0) {
        for (int i=0;i<[m_array_peripheral count];i++) {
           
            for (int i = 0; i <m_array_peripheral.count; i++) {
                BlePatrolPeripheral * l_per = [m_array_peripheral objectAtIndex:i];
                if ([disCoverPeripheral isEqual:l_per.m_peripheral]) {
                    l_per.m_peripheralRSSI = RSSI;
                    l_per.m_peripheralLocaName = peripheralID;
                   
                    return YES;
                }
            }
         
        }
    }
    
    return NO;
}




//取消BLE连接
- (void)cancelBLEConnection
{
    if ([Commom sharedInstance].currentPeripheral!=nil) {
        if ([Commom sharedInstance].currentPeripheral.state == CBPeripheralStateConnected) {
            [m_manger cancelPeripheralConnection:[Commom sharedInstance].currentPeripheral]; //取消连接
            
        }
    }

}

- (void)dealloc
{
    [_connectTimer setFireDate:[NSDate distantFuture]];
}

@end
