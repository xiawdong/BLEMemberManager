#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "Alpha_filter.h"

@interface Lock : NSObject

@property CBPeripheral *peripheral;@property NSString *lock_id;
@property NSString *mac;
@property int type;

@property double x;
@property double y;

@property double p0;
@property double n;
@property Alpha_filter *a_filter;

@property double rssi;
@property double rssi_a_filter;
@property double rssi_filter;

@property double open_lock_rssi_threshold;

@property int rssi_receive_cnt_between_remove_intv;

-(id)init: (CBPeripheral *)peripheral_val : (NSString *)lock_id_val : (NSString *)mac_val : (double)x_val : (double)y_val : (double)p0_val : (double)n_val : (double)rssi_thres_val;

-(void)set_para: (double)x_val : (double)y_val : (double)p0_val : (double)n_val : (double)rssi_thres_val;

-(void)set_rssi: (double)rssi_val;

@end
