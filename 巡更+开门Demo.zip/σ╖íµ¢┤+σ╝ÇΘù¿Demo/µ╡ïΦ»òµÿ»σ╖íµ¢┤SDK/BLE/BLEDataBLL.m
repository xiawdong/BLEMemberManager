//
//  BLEDataBLL.m
//  测试开门和巡更SDK
//
//  Created by xiaweidong on 16/6/22.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import "BLEDataBLL.h"
#import "StringConvert.h"


@implementation BLEDataBLL
#pragma mark--------------------
#pragma mark --处理读写门锁数据----
+ (void)bleMangerReceiveDoorLockData:(Byte *)resultByte WriteData:(NSString *)writeData Peripheral:(CBPeripheral *)peripheral write_Characteristic:(CBCharacteristic *)curCharacteristic isSuccess:(isSuccess)isSuccess
{
    if (writeData!=nil&&[[curCharacteristic.UUID UUIDString]isEqualToString:@"FFF1"]) {
        [peripheral writeValue:[StringConvert LockPickWithKeys:writeData] forCharacteristic:curCharacteristic type:CBCharacteristicWriteWithResponse];
    }
    
    //从BLE端读取开锁数据判断是否成功
    
    switch (resultByte[1]) {
        case 0x02:
            switch (resultByte[3]) {
                case 0x01:
                    isSuccess(NO);
                    break;
                case 0x02:
                    isSuccess(YES);
                    break;
                default:
                    break;
            }
            break;
        default:
            break;
    }
    
}
@end
