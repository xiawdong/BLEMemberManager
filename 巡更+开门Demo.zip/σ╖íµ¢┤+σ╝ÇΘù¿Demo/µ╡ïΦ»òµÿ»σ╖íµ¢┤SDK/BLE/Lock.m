#import "Lock.h"

@implementation Lock

@synthesize lock_id, mac, type, x, y, p0, n, a_filter, rssi, rssi_a_filter, rssi_filter, rssi_receive_cnt_between_remove_intv;

-(id)init: (CBPeripheral *)peripheral_val : (NSString *)lock_id_val : (NSString *)mac_val : (double)x_val : (double)y_val : (double)p0_val : (double)n_val : (double)rssi_thres_val
{
    self.peripheral = peripheral_val;    self.lock_id = lock_id_val;
    self.mac = mac_val;
    
    // 根据ID判断门锁的类型
    if ([[lock_id_val substringWithRange:NSMakeRange(0, 4)] isEqual: @"2111"]) {
        self.type = 1;
    } else if ([[lock_id_val substringWithRange:NSMakeRange(0, 4)] isEqual: @"2112"]) {
        self.type = 2;
    } else if ([[lock_id_val substringWithRange:NSMakeRange(0, 4)] isEqual: @"2113"]) {
        self.type = 3;
    } else if ([[lock_id_val substringWithRange:NSMakeRange(0, 4)] isEqual: @"2114"]) {
        self.type = 4;
    } else if ([[lock_id_val substringWithRange:NSMakeRange(0, 4)] isEqual: @"2115"]) {
        self.type = 5;
    } else {
        self.type = 0;
    }
    
    self.x = x_val;
    self.y = y_val;
    self.p0 = p0_val;
    self.n = n_val;
    
    self.a_filter = [[Alpha_filter alloc] init: 0.95];
    
    self.open_lock_rssi_threshold = rssi_thres_val;
    
    self.rssi_receive_cnt_between_remove_intv = 0;
    
    return self;
}

-(void)set_para: (double)x_val : (double)y_val : (double)p0_val : (double)n_val : (double)rssi_thres_val
{
    self.x = x_val;
    self.y = y_val;
    self.p0 = p0_val;
    self.n = n_val;
    self.open_lock_rssi_threshold = rssi_thres_val;
}

-(void)set_rssi: (double)rssi_val{
    self.rssi = rssi_val;
    
    [a_filter filter:rssi];
    self.rssi_a_filter = [a_filter get_result];
    
    self.rssi_filter = self.rssi_a_filter;
    
    rssi_receive_cnt_between_remove_intv += 1;
}

@end
