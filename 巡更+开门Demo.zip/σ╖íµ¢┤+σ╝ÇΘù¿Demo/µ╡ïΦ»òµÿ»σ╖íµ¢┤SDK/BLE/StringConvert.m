
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved.
//

#import "StringConvert.h"
#define format(str,...) [NSString stringWithFormat:str,## __VA_ARGS__]


@implementation StringConvert

//将ASCII转化为16进制
+ (NSData *)stringToByte:(NSString *)string
{
    NSString *hexString=[[string uppercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    if ([hexString length]%2!=0) {
        return nil;
    }
    Byte tempbyt[1]={0};
    NSMutableData* bytes=[NSMutableData data];
    for(int i=0;i<[hexString length];i++)
    {
        unichar hex_char1 = [hexString characterAtIndex:i]; ////两位16进制数中的第一位(高位*16)
        int int_ch1;
        if(hex_char1 >= '0' && hex_char1 <='9')
            int_ch1 = (hex_char1-48)*16;   //// 0 的Ascll - 48
        else if(hex_char1 >= 'A' && hex_char1 <='F')
            int_ch1 = (hex_char1-55)*16; //// A 的Ascll - 65
        else
            return nil;
        i++;
        
        unichar hex_char2 = [hexString characterAtIndex:i]; ///两位16进制数中的第二位(低位)
        int int_ch2;
        if(hex_char2 >= '0' && hex_char2 <='9')
            int_ch2 = (hex_char2-48); //// 0 的Ascll - 48
        else if(hex_char2 >= 'A' && hex_char2 <='F')
            int_ch2 = hex_char2-55; //// A 的Ascll - 65
        else
            return nil;
        
        tempbyt[0] = int_ch1+int_ch2;  ///将转化后的数放入Byte数组里
        [bytes appendBytes:tempbyt length:1];
    }
    return bytes;

}

//十六进制转换为普通字符串的。
+ (NSString *)ConvertHexStringToString:(NSString *)hexString {
    
    char *myBuffer = (char *)malloc((int)[hexString length] / 2 + 1);
    bzero(myBuffer, [hexString length] / 2 + 1);
    for (int i = 0; i < [hexString length] - 1; i += 2) {
        unsigned int anInt;
        NSString * hexCharStr = [hexString substringWithRange:NSMakeRange(i, 2)];
        NSScanner *scanner = [[NSScanner alloc] initWithString:hexCharStr];
        [scanner scanHexInt:&anInt];
        myBuffer[i / 2] = (char)anInt;
    }
    NSString *unicodeString = [NSString stringWithCString:myBuffer encoding:4];
//    NSLog(@"===字符串===%@",unicodeString);
    return unicodeString;
}

//普通字符串转换为十六进制
+ (NSString *)ConvertStringToHexString:(NSString *)string{
    NSData *myD = [string dataUsingEncoding:NSUTF8StringEncoding];
    NSString * hexStr = [StringConvert ConvertByteToHexString:myD];
    return hexStr;
}
//byte数组转为十六进制字符串
+ (NSString *)ConvertByteToHexString:(NSData *)data
{
    Byte *bytes = (Byte *)[data bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=0;i<[data length];i++)
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        
        if([newHexStr length]==1)
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return hexStr;

}

//int转data
+(NSData *)ConvertIntToData:(int)i
{

    NSData *data = [NSData dataWithBytes: &i length: sizeof(i)];
    return data;
}

//data转int
+(int)ConvertDataToInt:(NSData *)data{
    int i;
    [data getBytes:&i length:sizeof(i)];
    return i;
}

//十六进制转换为普通字符串的。
+ (NSData *)ConvertHexStringToData:(NSString *)hexString {
    
    NSData *data = [[StringConvert ConvertHexStringToString:hexString] dataUsingEncoding:NSUTF8StringEncoding];
    return data;
}


//根据UUIDString查找CBCharacteristic
+(CBCharacteristic *)findCharacteristicFormServices:(NSMutableArray *)services
                                         UUIDString:(NSString *)UUIDString{
    for (CBService *s in services) {
        for (CBCharacteristic *c in s.characteristics) {
            if ([c.UUID.UUIDString isEqualToString:UUIDString]) {
                return c;
            }
        }
    }
    return nil;
}


// 根据Byte下标和密钥 转PIN码
 
+ (NSString *)ConvertStringToPINString:(NSString *)KeyPairs ByteIndex:(int )ByteIndex
{
    Byte *rByte = (Byte *)[[StringConvert stringToByte:KeyPairs] bytes];
    int keys_value = ((rByte[ByteIndex]>>4)&0x0f)*4096+((rByte[ByteIndex])&0x0f)*256+((rByte[ByteIndex+1]>>4)&0x0f)*16+((rByte[ByteIndex+1])&0x0f);
    NSString * keys_input;
    if (keys_value<10) {
        keys_input = format(@"00000%d",keys_value);
    }else if(keys_value<100){
        keys_input = format(@"0000%d",keys_value);
    }else if(keys_value<1000){
        keys_input = format(@"000%d",keys_value);
    }else if(keys_value<10000){
        keys_input = format(@"00%d",keys_value);
    }else if(keys_value<100000){
        keys_input = format(@"0%d",keys_value);
    }else{
        keys_input = format(@"%d",keys_value);
    }
    return keys_input;
}
//根据密钥返回开锁Data数据
+ (NSData *)LockPickWithKeys:(NSString *)selectedkey
{
    Byte b[20];
    b[0] = 0x12;
    b[1] = 0x01;//开锁
    b[2] = 0x00;
    NSData *data =  [StringConvert stringToByte:selectedkey];
    Byte * testByte = (Byte *)[data bytes];
    for (int i = 3, k = 0; i < 19; i++, k++) {
        b[i] = testByte[k];
    }
    //19位
    Byte temp = 0x00;
    for (int j = 0; j < 19; j++) {
        temp = (Byte) (temp ^ b[j]);
        b[19] = temp;
    }
    NSData * newData = [[NSData alloc]initWithBytes:b length:20];
    return newData;
}

//解析扫描到的外设数据,并解析出p0N值,xy值

+ (NSArray *)ScanAdvertisementData:(NSDictionary *)advertisementData
{
    NSDictionary * dicti = advertisementData[@"kCBAdvDataServiceData"];
    NSArray *keyss;
    id  value1;
    id value;
    keyss = [dicti allKeys];
    for (int i = 0; i < dicti.count; i++){
        if (i ==1) {
            value1 = [dicti objectForKey:[keyss objectAtIndex:1]];
        }else if (i==0){
            value = [dicti objectForKey:[keyss objectAtIndex:0]];
        }
    }
    Byte *resultByte = (Byte *)[value1 bytes];
    Byte *xyByte = (Byte *)[value bytes];
    int x_input  = (((xyByte[0] & 0xFF)<<8)
                    |((xyByte[1] & 0xFF)<<0));
    
    int y_input  =  (((xyByte[2] & 0xFF)<<8)
                     |((xyByte[3] & 0xFF)<<0));
    
    Byte p0 =resultByte[0];
    Byte n =resultByte[1];
    
    int p0_input=0;
    if (p0&0x7f) {   //负数
        p0_input=0xffffff00| p0;
    }
    
    int n_input=0;
    if (n&0x7f) {   //负数
        n_input=0xffffff00| n;
    }
    NSArray * P0nXY = [[NSArray alloc]initWithObjects:@(p0_input),@(n_input),@(x_input),@(y_input), nil];
    return P0nXY;

}

//解析车牌信息

+ (NSString *)ScanPeripheralNumberPlate:(NSDictionary *)advertisementData
{
    NSString *numberPlate;
    NSDictionary * dicti = advertisementData[@"kCBAdvDataServiceData"];
    NSArray *keyss;
    NSData *  value0;
    keyss = [dicti allKeys];

    for (int i = 0; i < dicti.count; i++){
        if (i ==0) {
            value0 = [dicti objectForKey:[keyss objectAtIndex:0]];
        }
    }
    
//    Byte *resultByte = (Byte *)[value0 bytes];
//    for (int i = 0 ; i < [value0 length]; i ++) {
//        
//        printf("resultByte = %x\n",resultByte[i]);
//        
//    }
    NSString *aString = [StringConvert ConvertByteToHexString:value0];
   numberPlate = [StringConvert ConvertHexStringToString:aString];

    return numberPlate;
}

//根据广播数据解析固件版本号
+ (NSString *)DealWithDeviceVersion:(NSData *)data
{
    Byte *bytes = (Byte *)[data bytes];
    //下面是Byte 转换为16进制。
    NSString *hexStr=@"";
    for(int i=4;i<[data length]-2;i++)
        
    {
        NSString *newHexStr = [NSString stringWithFormat:@"%x",bytes[i]&0xff];///16进制数
        
        if([newHexStr length]==1)
            
            hexStr = [NSString stringWithFormat:@"%@0%@",hexStr,newHexStr];
        else
            hexStr = [NSString stringWithFormat:@"%@%@",hexStr,newHexStr];
    }
    return [StringConvert ConvertHexStringToString:hexStr];


}
@end


