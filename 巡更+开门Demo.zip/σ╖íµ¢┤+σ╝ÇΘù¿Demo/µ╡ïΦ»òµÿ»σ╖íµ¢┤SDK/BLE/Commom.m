//
//  Commom.m
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved
//

#import "Commom.h"

@implementation Commom
@synthesize currentPeripheral;

DEF_SINGLETON(Commom);


@end
