//
//  BLEmanager.h
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "Lock.h"

@protocol BLEMangerDelegate <NSObject>

@optional
- (void)bleMangerDidDiscoverPeripheral:(id)m_peripheral advertisementData:(NSDictionary *)advertisementData PeripheralType:(NSInteger)peripheralType;
- (void)bleMangerConnectedPeripheral:(BOOL)isConnect;
- (void)bleMangerDisConnectedPeripheral:(CBPeripheral *)m_peripheral;
- (void)bleMangerReceiveDataPeripheralData:(NSData *)data from_Characteristic:(CBCharacteristic *)curCharacteristic;


@end

@interface BLEmanager : NSObject<CBCentralManagerDelegate,CBPeripheralDelegate>


+(BLEmanager *)shareInstance;
@property (nonatomic,copy  ) NSMutableArray   *m_array_peripheral;
@property (nonatomic,strong) CBCentralManager *m_manger;
@property (nonatomic,strong) CBPeripheral     *m_peripheral;
@property (nonatomic,strong) CBCharacteristic *m_writeCharacteristic;
@property(nonatomic,assign)           BOOL     m_centralState;        //!<蓝牙状态
@property(weak,nonatomic)id<BLEMangerDelegate> mange_delegate;

-(void)initCentralManger;

/**
 *  取消BLE连接
 */
- (void)cancelBLEConnection;
@end
