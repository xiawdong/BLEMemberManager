//
//  BleNightpatrolPeripheral.h
//  BLEMemberManager
//
//  Created by xiaweidong on 16/3/11.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//巡更设备Model

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface BlePatrolPeripheral : NSObject

@property (nonatomic,copy) CBPeripheral *m_peripheral;        //!<巡更外设
@property (nonatomic,copy) NSString     *m_peripheralType;
@property (nonatomic,copy) NSString     *m_peripheralLocaName; //!<巡更外设ID
@property (nonatomic,copy) NSNumber     *m_peripheralRSSI;

@end
