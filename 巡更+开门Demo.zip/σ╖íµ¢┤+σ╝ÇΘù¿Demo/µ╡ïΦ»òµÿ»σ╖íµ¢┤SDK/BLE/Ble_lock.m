#import "Ble_lock.h"

@implementation Ble_lock

@synthesize locks, timer_rm_locks, scene;

-(id)init
{
    self.locks = [[NSMutableArray alloc] init];
    self.scene = 1;
    [self init_timer:5.0f];
    
    return self;
}

// 定时器回调函数，用于清除已丢失的门锁
-(void)timer_rm_locks_cb
{
    int i;
    
    for (i = 0; i < locks.count; i++) {
        Lock *lock =(Lock *)[locks objectAtIndex:i];
        if (lock.rssi_receive_cnt_between_remove_intv == 0) {
            [locks removeObjectAtIndex:i];
            i--;
        } else {
            lock.rssi_receive_cnt_between_remove_intv = 0;
        }
    }
    
    // NSLog(@"Timer: remove locks");
}

-(void)init_timer: (double)rm_intv
{
    self.timer_rm_locks = [NSTimer scheduledTimerWithTimeInterval:rm_intv target:self selector:@selector(timer_rm_locks_cb) userInfo:nil repeats:YES];
}

// 根据ID获取门锁对象
-(Lock *)get_lock: (NSString *)lock_id
{
    int i;
    
    for (i = 0; i < locks.count; i++) {
        Lock *lock = (Lock *)[locks objectAtIndex:i];
        if ([lock.lock_id isEqualToString:lock_id]) {
            return lock;
        }
    }
    
    return NULL;
}

// 判断门锁是否已存在
-(BOOL)is_lock_exist: (NSString *)lock_id
{
    if ([self get_lock:lock_id] == NULL) {
        return false;
    } else {
        return true;
    }
}

// 添加门锁
-(void)add_lock:(CBPeripheral *)peripheral : (NSString *)lock_id :(NSString *)mac :(double)x :(double)y :(double)p0 :(double)n :(double)rssi_thres_val
{
    if (lock_id.length == 12) {  // TODO
        if ([self is_lock_exist:lock_id]) {
            Lock *lock = [self get_lock:lock_id];
            [lock set_para:x :y :p0 :n :rssi_thres_val];
        } else {
            [locks addObject:[[Lock alloc] init:peripheral :lock_id :mac :x :y :p0 :n :rssi_thres_val]];
        }
    }
}

// 根据ID设置对应门锁的RSSI
-(void)set_rssi: (NSString *)lock_id : (double)rssi
{
    if (rssi < -120 || rssi > -30) {
        return;
    }
    
    Lock *lock = (Lock *)[self get_lock:lock_id];
    if (lock != NULL) {
        [lock set_rssi:rssi];
    }
}

-(Lock *)get_lock_to_open
{
    Lock *lock;
    int lock_type;
    int i;
    
    /* 未收到任何门锁广播的场景 */
    if (locks.count <= 0) {
        scene = 0;
        
        return NULL;
    }
    
    NSSortDescriptor *sd = [[NSSortDescriptor alloc] initWithKey:@"rssi_filter" ascending:NO];
    NSArray *sds = [NSArray arrayWithObject:sd];
    NSArray *sorted_locks = [locks sortedArrayUsingDescriptors:sds];
    [locks removeAllObjects];
    [locks addObjectsFromArray:sorted_locks];
    
    /* 判断应用场景，主要根据门锁的类型和各门锁的RSSI值大小进行判断 */
    /* 只有排在前面的门锁的RSSI超过了它自己的开锁门限时，才将这个门锁作为判断场景的依据，为了避免以下情形：
     *     有两个门锁A和B，A没有遮挡，B有金属遮挡，开锁距离门限都是3m，经测试，A的RSSI门限是-70，B的RSSI门限是-80。
     *     站在离A 4m，离B 2m的地方，实际收到的A的RSSI为-74，B的RSSI为-76。
     *     如果不判断A的RSSI是否超过开锁门限（这里没超过，因为-74 < -70），直接将A作为判断场景的依据，那么结果是
     *     既开不了A，也开不了B，而真正应该开的锁是B（因为-76 > -80）。 */
    lock = NULL;
    for (i = 0; i < locks.count; i++) {
        lock = (Lock *)[locks objectAtIndex:i];
        if (lock.rssi_filter >= lock.open_lock_rssi_threshold) {
            break;
        }
    }
    
    if (lock != NULL) {
        lock_type = lock.type;	/* RSSI最大的有效门锁的类型 */
        if (lock_type == 1) {
            scene = 1;
            
            return lock;
        } else if (lock_type == 2 || lock_type == 3) {
            scene = 2;
            
            for (i = 0; i < locks.count; i++) {
                /* 寻找门内的控制门锁 */
                lock = (Lock *)[locks objectAtIndex:i];
                if (lock.type == 2) {
                    return lock;
                }
            }
        } else if (lock_type == 4 || lock_type == 5) {
            scene = 3;
            
            for (i = 0; i < locks.count; i++) {
                /* 寻找门外的控制门锁 */
                lock = (Lock *)[locks objectAtIndex:i];
                if (lock.type == 4) {
                    return lock;
                }
            }
        } else {
            scene = 0;	/* 未定义的场景！ */
            
            return NULL;
        }
    }
    
    return NULL;
}

@end
