#import <Foundation/Foundation.h>

@interface Alpha_filter : NSObject

@property double alpha;
@property int phase;
@property double data_out;

-(id)init: (double)alpha_val;

-(void)filter: (double)data_in;

-(double)get_result;

@end