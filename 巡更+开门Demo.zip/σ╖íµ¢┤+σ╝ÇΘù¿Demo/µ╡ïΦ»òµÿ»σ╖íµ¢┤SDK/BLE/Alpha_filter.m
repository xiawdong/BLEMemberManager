#import "Alpha_filter.h"

@implementation Alpha_filter

@synthesize alpha, phase, data_out;

-(id)init: (double)alpha_val
{
    self.alpha = alpha_val;
    self.phase = 0;
    
    return self;
}

// 对输入数据进行alpha滤波
-(void)filter: (double)data_in
{
    if (phase == 0) {
        data_out = data_in;
        phase = 1;
    } else if (phase == 1) {
        data_out = alpha * data_out + (1 - alpha) * data_in;
    }
}

-(double)get_result
{
    return data_out;
}

@end