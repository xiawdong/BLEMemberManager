//
//  openTheDoorViewController.m
//  测试是巡更SDK
//
//  Created by xiaweidong on 16/6/23.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import "openTheDoorViewController.h"
//#import <BLEMemberManager/BLEMemberManager.h>
#import "BLEMemberManager.h"

@interface openTheDoorViewController ()<BLEMangerDelegate>
{
    BLEmanager *m_bleManger;
    Lock *lock;
    Ble_lock * ble_lock;
}
@property (weak, nonatomic) IBOutlet UIButton *openDoor;

@property (nonatomic,copy)NSString *codeKey;//!<密钥

@end

@implementation openTheDoorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1.设置代理
    m_bleManger = [BLEmanager shareInstance];
    m_bleManger.mange_delegate = self;
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    //2.不用是设置代理为nil
//    m_bleManger.mange_delegate = nil;
    
}


- (IBAction)openDoor_clock:(UIButton *)sender {
    //0.判断蓝牙是否打开
    if ([BLEmanager shareInstance].m_centralState) {
        NSLog(@"蓝牙开启");
    }else{
        NSLog(@"蓝牙关闭");
    }
    //1.拿到需要打开的门锁
    lock = [ble_lock get_lock_to_open];
    
    if (lock != nil) {
       
        //2.根据 lock.lock_id 找到对应的密钥
        //这里顺便设置的一个字符串密钥
        _codeKey = @"7076f1caadff484eae1138cc0824fa0b"; //@"af8ca4bc42d44e5e9924ed1d5cf72bcd";
        if (_codeKey == nil) {
            return ;
        }
        // 回到主线程
        dispatch_async(dispatch_get_main_queue(), ^{
            //3.连接开门
            [m_bleManger.m_manger connectPeripheral:lock.peripheral options:nil];
            NSLog(@"%@---%@",lock.peripheral,lock.lock_id);
            
        });
        
    }else{
        NSLog(@"lock为空");
        return;
    }
}
#pragma mark -----
#pragma mark BLEmange_delegate
- (void)bleMangerDidDiscoverPeripheral:(id)m_peripheral advertisementData:(NSDictionary *)advertisementData PeripheralType:(NSInteger)peripheralType

{
    
    switch (peripheralType) {
        case 2111://门锁类型
            ble_lock = m_peripheral;
            break;
        default:
            break;
    }
    
}

- (void)bleMangerConnectedPeripheral:(BOOL)isConnect
{
    if (isConnect) {
        NSLog(@"连接成功");
    }
    [m_bleManger.m_manger stopScan];
    
}
- (void)bleMangerDisConnectedPeripheral:(CBPeripheral *)m_peripheral
{
     NSLog(@"已经断开了链接");
}
- (void)bleMangerReceiveDataPeripheralData:(NSData *)data from_Characteristic:(CBCharacteristic *)curCharacteristic
{
    Byte *resultByte = (Byte *)[data bytes];
    
    [BLEDataBLL bleMangerReceiveDoorLockData:resultByte WriteData:_codeKey Peripheral:[BLEmanager shareInstance].m_peripheral write_Characteristic:curCharacteristic isSuccess:^(BOOL isSuccess) {
        if (isSuccess==YES) {
            NSLog(@"开门成功");
        }else{
            
        }
        
    }];
    
}


@end
