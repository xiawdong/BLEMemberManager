//
//  ViewController.m
//  测试是巡更SDK
//
//  Created by xiaweidong on 16/2/25.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import "ViewController.h"
//#import <BLEMemberManager/BLEMemberManager.h>
#import "BLEMemberManager.h"

@interface ViewController ()<BLEMangerDelegate,UITableViewDataSource,UITableViewDelegate>
{
    BLEmanager *m_bleManger;
}

@property(nonatomic,strong)UITableView *m_tableView;
@property(nonatomic,copy)NSMutableArray *array;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (!_m_tableView) {
        _m_tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0,320 , 480)];
        _m_tableView.delegate = self;
        _m_tableView.dataSource = self;
        
    }
    [self.view addSubview:_m_tableView];
    
    //1.设置代理
    m_bleManger = [BLEmanager shareInstance];
    m_bleManger.mange_delegate = self;
    
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    //2.不用是设置代理为nil
//    m_bleManger.mange_delegate = nil;

}
#pragma mark -----
#pragma mark ------BLEmange_delegate-----
- (void)bleMangerDidDiscoverPeripheral:(id)m_peripheral advertisementData:(NSDictionary *)advertisementData PeripheralType:(NSInteger)peripheralType

{
    
    switch (peripheralType) {
        case 1311://巡更类型
            _array = [BLEmanager shareInstance].m_array_peripheral;
            
            NSLog(@"设备ID:%@ 设备模型数组:%@",m_peripheral,_array);
            
            [_m_tableView reloadData];
            break;
            
        default:
            break;
    }
    
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    return 60;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    
    return _array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSString *cellIden = [NSString stringWithFormat:@"%ld%ld",(long)indexPath.section,(long)indexPath.row];
    UITableViewCell *mycell = [tableView dequeueReusableCellWithIdentifier:cellIden];
    
    if (!mycell) {
        mycell  = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIden];
    }
    
    BlePatrolPeripheral * patrol =[_array objectAtIndex:indexPath.row];
    mycell.textLabel.text =  [NSString stringWithFormat:@"巡更设备ID:%@",patrol .m_peripheralLocaName];
    
    return mycell;
    
    
}

#pragma mark -----------
- (NSMutableArray *)array
{
    if (!_array) {
        _array = [NSMutableArray array];
    }
    return _array;
    
}
@end
