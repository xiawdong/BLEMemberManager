//
//  AppDelegate.h
//  测试是巡更SDK
//
//  Created by xiaweidong on 16/2/25.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

