//
//  BLEDataBLL.h
//  测试开门和巡更SDK
//
//  Created by xiaweidong on 16/6/22.
//  Copyright © 2016年 xiaweidong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

typedef void(^isSuccess)(BOOL isSuccess);

@interface BLEDataBLL : NSObject
/**
 *  读写门锁数据
 */
+ (void)bleMangerReceiveDoorLockData:(Byte *)resultByte WriteData:(NSString *)writeData Peripheral:(CBPeripheral *)peripheral write_Characteristic:(CBCharacteristic *)curCharacteristic isSuccess:(isSuccess)isSuccess;
@end
