#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import "Lock.h"

@interface Ble_lock : NSObject

@property NSMutableArray *locks;
@property NSTimer *timer_rm_locks;
@property int scene;

-(id)init;

-(void)timer_rm_locks_cb;

-(void)init_timer: (double)rm_intv;

-(Lock *)get_lock: (NSString *)lock_id;

-(BOOL)is_lock_exist: (NSString *)lock_id;

-(void)add_lock:(CBPeripheral *)peripheral : (NSString *)lock_id :(NSString *)mac :(double)x :(double)y :(double)p0 :(double)n :(double)rssi_thres_val;

-(void)set_rssi: (NSString *)lock_id : (double)rssi;

-(Lock *)get_lock_to_open;

@end
