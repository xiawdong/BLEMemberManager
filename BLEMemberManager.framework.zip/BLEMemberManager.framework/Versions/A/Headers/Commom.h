//
//  Commom.h
//  BLE4.0
//
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved
//


#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

//单例
#undef	AS_SINGLETON
#define AS_SINGLETON( __class ) \
+ (__class *)sharedInstance;

#undef	DEF_SINGLETON
#define DEF_SINGLETON( __class ) \
+ (__class *)sharedInstance \
{ \
static dispatch_once_t once; \
static __class * __singleton__; \
dispatch_once( &once, ^{ __singleton__ = [[__class alloc] init]; } ); \
return __singleton__; \
}


@interface Commom : NSObject
AS_SINGLETON(Commom);

@property(nonatomic,copy)CBPeripheral *currentPeripheral;

@end
