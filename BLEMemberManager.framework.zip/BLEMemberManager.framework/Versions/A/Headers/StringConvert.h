
//  Created by xiaweidong on 15/8/28.
//  Copyright (c) 2015年 云凯科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface StringConvert : NSObject

/**
 *  将ASCII转化为16进制
 */
+(NSData*)stringToByte:(NSString*)string;

/**
 *  16进制数据转换成字符串
 */
+ (NSString *)ConvertHexStringToString:(NSString *)hexString;

/**
 *  普通字符串转换为十六进制
 */
+ (NSString *)ConvertStringToHexString:(NSString *)string;

/**
 *  byte数组转为十六进制字符串
 */
+ (NSString *)ConvertByteToHexString:(NSData *)data;

/**
 *  int转data
 */
+(NSData *)ConvertIntToData:(int)i;

/**
 *  data转int
 */
+(int)ConvertDataToInt:(NSData *)data;

//十六进制转换为普通字符串的。
+ (NSData *)ConvertHexStringToData:(NSString *)hexString;
//根据UUIDString查找CBCharacteristic
+(CBCharacteristic *)findCharacteristicFormServices:(NSMutableArray *)services
                                         UUIDString:(NSString *)UUIDString;

/**
 *  根据Byte下标和密钥 转PIN码
 */
+ (NSString *)ConvertStringToPINString:(NSString *)KeyPairs ByteIndex:(int )ByteIndex;

/**
 *  根据传入密钥返回开锁data数据
 */
+ (NSData *)LockPickWithKeys:(NSString *)selectedkey;

/**
 *  解析扫描到的外设数据,并解析出p0N值,XY值
 *  pranm :扫描到的外设数据包
 */
+ (NSArray *)ScanAdvertisementData:(NSDictionary *)advertisementData;


/**
 *  解析扫描到的外设数据,并解析出车牌
 *
 *  pranm :扫描到的外设数据包
 */
+ (NSString *)ScanPeripheralNumberPlate:(NSDictionary *)advertisementData;

/**
 *  根据广播数据解析固件版本号
 *
 *  @param data ble广播数据
 *
 *  @return 固件版本号
 */
+ (NSString *)DealWithDeviceVersion:(NSData *)data;
@end
